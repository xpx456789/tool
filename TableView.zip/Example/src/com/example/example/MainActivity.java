package com.example.example;



import java.util.HashMap;
import java.util.Map;





import com.xpx.tableview.model.TableDataModel;
import com.xpx.tableview.model.TableModel;
import com.xpx.tableview.widget.TableView;

import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends
		Activity {
	public TableView mTableView;
	public TableDataModel mTableData;
	@Override
	protected void onCreate(
			Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mTableView = (TableView) this.findViewById(R.id.table);
		mTableData = new TableDataModel();
		for(int i = 0 ; i < 20 ; i++)
		{
			mTableData.getmTableHead().add(new TableModel("title"+String.valueOf(i),"title"+String.valueOf(i)));
		}
		for(int i= 0 ; i < 20 ; i++)
		{
			HashMap<String, String> tmp = new HashMap<String, String>();
			for(TableModel mTableModel : mTableData.getmTableHead())
			{
				tmp.put(mTableModel.getmFeild(), "��Ŀ"+mTableModel.getmCatpion());
			}
			mTableData.getmTableData().add(tmp);
		}
		mTableView.setData(mTableData);
	}
}
